package sb.techcamp.bankapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import sb.techcamp.bankapi.model.Account;
import sb.techcamp.bankapi.model.Client;

public interface AccountRepository extends JpaRepository<Account, Long> {



}